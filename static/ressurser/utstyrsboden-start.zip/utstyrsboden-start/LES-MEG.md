# Utstyrsboden – første kodeoppgave

Bruk oppgaveteksten i IT-laben: /databaser/praksis/.
Du trenger Node.js 22 eller nyere og tilgang til en MongoDB-database for deg eller gruppen.

1. Åpne denne mappen i editoren og terminalen.
2. Kjør `npm install mongodb`.
3. Kopier .env.example til .env. Fyll inn URI og databasenavn fra læreren.
4. Kjør `node --env-file=.env klargjor.mjs`.
5. Kjør `node --env-file=.env finn.mjs`.
6. Skriv egne filtre i finn.mjs. Start med alle mikrofoner, og deretter ledige kameraer til høyst 300 kr.

Klargjøringen legger bare til dokumenter med nye ID-er. Den overskriver og sletter ikke eksisterende data.
I en tom collection skal startdatasettet gi seks dokumenter. Vil du legge til et eget fiktivt dokument,
utvid utstyr.json med en ubrukt tekst-ID og kjør klargjøringen igjen. Bruk samme felter og datatyper.

En gyldig spørring uten treff gir en tom liste. En teknisk feil gir en feilmelding og avslutter med feilkode.
Behold koden og resultater fra kjøringer, og forklar hvorfor ett dokument blir med og et annet faller utenfor.

Del aldri .env, passord eller hele tilkoblingsstrengen. 127.0.0.1 betyr din egen maskin.
Hvis MongoDB kjører på skoleserveren, skal du bruke adressen og begrenset tilgang fra læreren.
MongoDB skal ikke kontaktes direkte fra frontend; denne øvingen kjører i Node.js.
Dette er bare fiktive øvingsdata. Prosjektet gir ikke automatisk vurdering eller XP i IT-laben.
