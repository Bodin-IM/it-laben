import { MongoClient } from 'mongodb';

// Kjør med: node --env-file=.env eksempel.mjs
const uri = process.env.MONGODB_URI;
const database = process.env.MONGODB_DATABASE;
if (!uri || !database) {
  console.error('Fyll inn MONGODB_URI og MONGODB_DATABASE i .env.');
  process.exit(1);
}

const client = new MongoClient(uri, { serverSelectionTimeoutMS: 5000 });
try {
  // 1. Koble til og velg hvor vi skal arbeide.
  await client.connect();
  const utstyr = client.db(database).collection('utstyr');

  // 2. Hent kameraer fra de klargjorte eksempeldataene.
  const kameraer = await utstyr.find({ kategori: 'kamera' }).toArray();
  console.log('Kameraer:');
  console.table(kameraer);

  // 3. Legg inn ett nytt dokument i din egen øvingsdatabase.
  const nyttUtstyr = {
    "_id": "M203",
    "navn": "Mikrofon Bord",
    "kategori": "mikrofon",
    "tilgjengelig": true,
    "dagspris": 120
  };
  try {
    const bekreftelse = await utstyr.insertOne(nyttUtstyr);
    console.log('Lagret med ID:', bekreftelse.insertedId);
  } catch (feil) {
    if (feil.code !== 11000) throw feil;
    console.log('En unik verdi er allerede i bruk. Ingen data er overskrevet.');
  }

  // 4. Hent på nytt for å undersøke hva som faktisk ligger i databasen.
  const mikrofoner = await utstyr.find({ kategori: 'mikrofon' }).toArray();
  console.log('Mikrofoner:');
  console.table(mikrofoner);
} catch {
  console.error('Kjøringen feilet. Kontroller oppsett og datatilgang med læreren. Ikke del URI eller passord.');
  process.exitCode = 1;
} finally {
  // Dette terminalprogrammet er ferdig. Dokumentene blir liggende.
  await client.close();
}
