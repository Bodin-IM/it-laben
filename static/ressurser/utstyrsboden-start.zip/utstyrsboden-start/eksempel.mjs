import { MongoClient } from 'mongodb';

const databaseFailure = function databaseFailure(error, stage) {
	if (error?.code === 18) return '[INNLOGGING] Databasen avviste innloggingen. Be læreren kontrollere bruker og innloggingsdatabase. Ikke del .env.';
	if (error?.code === 13) return '[TILGANG] Brukeren mangler tilgang til operasjonen. Be læreren kontrollere rettighetene til øvingsdatabasen.';
	if (error?.code === 11000) return '[DUPLIKAT] En unik verdi er allerede i bruk. Bruk en ny ID for et nytt dokument. Eksisterende data er ikke overskrevet.';
	if (error?.name === 'MongoParseError' || error?.name === 'MongoInvalidArgumentError') return '[OPPSETT] Kontroller formatet på MONGODB_URI i .env sammen med læreren. Ikke del tilkoblingsstrengen.';
	if (stage === 'kobling' || error?.name === 'MongoServerSelectionError' || error?.name === 'MongoNetworkError') return '[KONTAKT] Kunne ikke opprette eller beholde forbindelsen. Kontroller serveradresse, nettverk og om MongoDB kjører. localhost betyr denne maskinen.';
	if (stage === 'data') return '[STARTDATA] Kontroller JSON, felttyper og unike ID-er i utstyr.json. Ingen eksisterende dokumenter er slettet.';
	if (stage === 'lagring') return '[LAGRING] Innsettingen kunne ikke bekreftes. Hent data på nytt for å undersøke hva som finnes før du prøver igjen.';
	return '[LESING] Søket kunne ikke fullføres. Kontroller filteret og databasetilgangen. Dette er forskjellig fra en vellykket kjøring med null treff.';
};

// Kjør med: node --env-file=.env eksempel.mjs
const uri = process.env.MONGODB_URI;
const database = process.env.MONGODB_DATABASE;
if (!uri || !database) {
  console.error('[OPPSETT] Fyll inn MONGODB_URI og MONGODB_DATABASE i .env.');
  process.exit(1);
}

let client;
let stage = 'kobling';
try {
  client = new MongoClient(uri, { serverSelectionTimeoutMS: 5000 });
  // 1. Koble til og velg hvor vi skal arbeide.
  await client.connect();
  stage = 'lesing';
  const utstyr = client.db(database).collection('utstyr');

  // 2. Hent kameraer fra de klargjorte eksempeldataene.
  const kameraer = await utstyr.find({ kategori: 'kamera' }).toArray();
  console.log('Kameraer:');
  console.table(kameraer);

  // 3. Legg inn ett nytt dokument i din egen øvingsdatabase.
  const nyttUtstyr = {
    "_id": "M203",
    "navn": "Mikrofon Bord",
    "kategori": "mikrofon",
    "tilgjengelig": true,
    "dagspris": 120
  };
  stage = 'lagring';
  try {
    const bekreftelse = await utstyr.insertOne(nyttUtstyr);
    console.log('Lagret med ID:', bekreftelse.insertedId);
  } catch (feil) {
    if (feil.code !== 11000) throw feil;
    console.log('En unik verdi er allerede i bruk. Ingen data er overskrevet.');
  }

  // 4. Hent på nytt for å undersøke hva som faktisk ligger i databasen.
  stage = 'lesing';
  const mikrofoner = await utstyr.find({ kategori: 'mikrofon' }).toArray();
  console.log('Mikrofoner:');
  console.table(mikrofoner);
} catch (error) {
  console.error(databaseFailure(error, stage));
  process.exitCode = 1;
} finally {
  // Dette terminalprogrammet er ferdig. Dokumentene blir liggende.
  await client?.close();
}
