import { MongoClient } from 'mongodb';

const uri = process.env.MONGODB_URI;
const database = process.env.MONGODB_DATABASE;
if (!uri || !database) {
  console.error('Fyll inn MONGODB_URI og MONGODB_DATABASE i .env.');
  process.exit(1);
}

const client = new MongoClient(uri, { serverSelectionTimeoutMS: 5000 });
try {
  await client.connect();
  const utstyr = client.db(database).collection('utstyr');

  // Start med alle dokumentene. Skriv deretter dine egne søk.
  const filter = {};
  const resultat = await utstyr.find(filter).toArray();
  console.table(resultat);
} catch {
  console.error('Kjøringen feilet. Kontroller serveradresse, tilgang og kode. Be læreren om hjelp uten å dele passord eller tilkoblingsstreng.');
  process.exitCode = 1;
} finally {
  await client.close();
}
