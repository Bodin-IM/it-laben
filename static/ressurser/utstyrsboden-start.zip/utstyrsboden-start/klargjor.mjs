import { MongoClient } from 'mongodb';
import { readFile } from 'node:fs/promises';

const uri = process.env.MONGODB_URI;
const database = process.env.MONGODB_DATABASE;
if (!uri || !database) {
  console.error('Fyll inn MONGODB_URI og MONGODB_DATABASE i .env.');
  process.exit(1);
}
const client = new MongoClient(uri, { serverSelectionTimeoutMS: 5000 });
try {
  const data = JSON.parse(await readFile(new URL('./utstyr.json', import.meta.url), 'utf8'));
  if (!Array.isArray(data) || data.length > 100 || data.some((item) =>
    !item || typeof item._id !== 'string' || !item._id.trim() ||
    typeof item.navn !== 'string' || typeof item.kategori !== 'string' ||
    typeof item.tilgjengelig !== 'boolean' || typeof item.dagspris !== 'number' ||
    !Number.isFinite(item.dagspris) || item.dagspris < 0) ||
    new Set(data.map((item) => item._id)).size !== data.length) {
    throw new Error('Kontroller feltene og unike tekst-ID-er i utstyr.json.');
  }
  await client.connect();
  const utstyr = client.db(database).collection('utstyr');
  let inserted = 0;
  for (const item of data) {
    // Bare nye ID-er legges til. Eksisterende dokumenter blir ikke overskrevet.
    const result = await utstyr.updateOne({ _id: item._id }, { $setOnInsert: item }, { upsert: true });
    inserted += result.upsertedCount;
  }
  console.log('Nye dokumenter lagt til:', inserted);
  console.log('Eksisterende dokumenter er beholdt. Kjør finn.mjs for å undersøke dataene.');
} catch {
  console.error('Klargjøringen feilet. Kontroller utstyr.json, .env og databasetilgangen. Eksisterende dokumenter er ikke slettet. Skriptet kan kjøres på nytt etter retting.');
  process.exitCode = 1;
} finally {
  await client.close();
}
