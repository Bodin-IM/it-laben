import { MongoClient } from 'mongodb';
import { readFile } from 'node:fs/promises';

const databaseFailure = function databaseFailure(error, stage) {
	if (error?.code === 18) return '[INNLOGGING] Databasen avviste innloggingen. Be læreren kontrollere bruker og innloggingsdatabase. Ikke del .env.';
	if (error?.code === 13) return '[TILGANG] Brukeren mangler tilgang til operasjonen. Be læreren kontrollere rettighetene til øvingsdatabasen.';
	if (error?.code === 11000) return '[DUPLIKAT] En unik verdi er allerede i bruk. Bruk en ny ID for et nytt dokument. Eksisterende data er ikke overskrevet.';
	if (error?.name === 'MongoParseError' || error?.name === 'MongoInvalidArgumentError') return '[OPPSETT] Kontroller formatet på MONGODB_URI i .env sammen med læreren. Ikke del tilkoblingsstrengen.';
	if (stage === 'kobling' || error?.name === 'MongoServerSelectionError' || error?.name === 'MongoNetworkError') return '[KONTAKT] Kunne ikke opprette eller beholde forbindelsen. Kontroller serveradresse, nettverk og om MongoDB kjører. localhost betyr denne maskinen.';
	if (stage === 'data') return '[STARTDATA] Kontroller JSON, felttyper og unike ID-er i utstyr.json. Ingen eksisterende dokumenter er slettet.';
	if (stage === 'lagring') return '[LAGRING] Innsettingen kunne ikke bekreftes. Hent data på nytt for å undersøke hva som finnes før du prøver igjen.';
	return '[LESING] Søket kunne ikke fullføres. Kontroller filteret og databasetilgangen. Dette er forskjellig fra en vellykket kjøring med null treff.';
};

const uri = process.env.MONGODB_URI;
const database = process.env.MONGODB_DATABASE;
if (!uri || !database) {
  console.error('[OPPSETT] Fyll inn MONGODB_URI og MONGODB_DATABASE i .env.');
  process.exit(1);
}
let client;
let stage = 'data';
try {
  const data = JSON.parse(await readFile(new URL('./utstyr.json', import.meta.url), 'utf8'));
  if (!Array.isArray(data) || data.length > 100 || data.some((item) =>
    !item || typeof item._id !== 'string' || !item._id.trim() ||
    typeof item.navn !== 'string' || typeof item.kategori !== 'string' ||
    typeof item.tilgjengelig !== 'boolean' || typeof item.dagspris !== 'number' ||
    !Number.isFinite(item.dagspris) || item.dagspris < 0) ||
    new Set(data.map((item) => item._id)).size !== data.length) {
    throw new Error('Kontroller feltene og unike tekst-ID-er i utstyr.json.');
  }
  stage = 'kobling';
  client = new MongoClient(uri, { serverSelectionTimeoutMS: 5000 });
  await client.connect();
  stage = 'lagring';
  const utstyr = client.db(database).collection('utstyr');
  let inserted = 0;
  for (const item of data) {
    // Bare nye ID-er legges til. Eksisterende dokumenter blir ikke overskrevet.
    const result = await utstyr.updateOne({ _id: item._id }, { $setOnInsert: item }, { upsert: true });
    inserted += result.upsertedCount;
  }
  console.log('Nye dokumenter lagt til:', inserted);
  console.log('Eksisterende dokumenter er beholdt. Kjør finn.mjs for å undersøke dataene.');
} catch (error) {
  console.error(databaseFailure(error, stage));
  console.error('Klargjøringen kan ha lagt til noen av dokumentene. Kjør den på nytt etter retting; eksisterende ID-er blir ikke overskrevet.');
  process.exitCode = 1;
} finally {
  await client?.close();
}
